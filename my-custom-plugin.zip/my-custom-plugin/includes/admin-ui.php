<?php
// Admin menu setup
add_action('admin_menu', 'mrbs_admin_menu');

function mrbs_admin_menu() {
    add_menu_page('Meeting Rooms', 'Meeting Rooms', 'manage_options', 'mrbs-room-list', 'mrbs_room_list_page', 'dashicons-building', 6);
    add_submenu_page('mrbs-room-list', 'Add Room', 'Add Room', 'manage_options', 'mrbs-add-room', 'mrbs_add_room_page');
}

function mrbs_room_list_page() {
    echo '<div class="wrap"><h1>All Meeting Rooms</h1>';
    echo '<p>List rooms here (we’ll add real data soon).</p></div>';
}

function mrbs_add_room_page() {
    echo '<div class="wrap"><h1>Add New Meeting Room</h1>';
    echo '<form method="post">';
    echo '<input type="text" name="room_name" placeholder="Room Name" required />';
    echo '<br><textarea name="room_description" placeholder="Room Description"></textarea>';
    echo '<br><input type="submit" name="mrbs_save_room" value="Add Room" class="button button-primary" />';
    echo '</form></div>';

    if (isset($_POST['mrbs_save_room'])) {
        global $wpdb;
        $table = $wpdb->prefix . 'meeting_rooms';
        $wpdb->insert($table, [
            'name' => sanitize_text_field($_POST['room_name']),
            'description' => sanitize_textarea_field($_POST['room_description']),
        ]);
        echo '<div class="notice notice-success"><p>Room added successfully!</p></div>';
    }
}
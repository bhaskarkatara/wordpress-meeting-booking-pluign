<?php

function mrbs_save_booking($room_id, $date, $time, $user_id) {
    global $wpdb;

    $table = $wpdb->prefix . 'meeting_bookings';

    $exists = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table WHERE room_id = %d AND booking_date = %s AND booking_time = %s",
        $room_id, $date, $time
    ));

    if ($exists > 0) {
        return "❌ This slot is already booked.";
    }

    $wpdb->insert($table, [
        'room_id' => $room_id,
        'booking_date' => $date,
        'booking_time' => $time,
        'booked_by' => $user_id,
    ]);

    return "✅ Booking successful!";
}
<?php

function mrbs_create_tables() {
    error_log("✅ Table creation function ran!");

    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    $room_table = $wpdb->prefix . 'meeting_rooms';
    $booking_table = $wpdb->prefix . 'meeting_bookings';

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    $sql_rooms = "CREATE TABLE $room_table (
        id INT NOT NULL AUTO_INCREMENT,
        name VARCHAR(255) NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    $sql_bookings = "CREATE TABLE $booking_table (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_id INT NOT NULL,
    booking_date DATE NOT NULL,
    booking_time TIME NOT NULL,
    booked_by INT,
    title VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) $charset_collate;";


    dbDelta($sql_rooms);
    dbDelta($sql_bookings);
}

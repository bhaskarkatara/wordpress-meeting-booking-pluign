<?php
// Register shortcode for booking form
add_shortcode('book_meeting_room', 'mrbs_booking_form');

function mrbs_booking_form() {
    ob_start();
    include plugin_dir_path(__FILE__) . '../templates/form-book-room.php';
    return ob_get_clean();
}

// Register shortcode for viewing bookings
add_shortcode('view_meeting_bookings', 'mrbs_view_bookings_page');

function mrbs_view_bookings_page() {
    ob_start();

    include plugin_dir_path(__FILE__) . '../templates/view-bookings.php';
    
    return ob_get_clean();
}
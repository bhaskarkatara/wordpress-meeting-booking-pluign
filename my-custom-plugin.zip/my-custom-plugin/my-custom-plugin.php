<?php
/**
 * Plugin Name: Meeting Room Booking System
 * Description: Allows admin to manage meeting rooms and users to book 1-hour slots.
 * Version: 1.0
 * Author: Bhaskar Katara
 */

defined('ABSPATH') || exit;

// Load dependencies
require_once plugin_dir_path(__FILE__) . 'includes/db-functions.php';
require_once plugin_dir_path(__FILE__) . 'includes/admin-ui.php';
require_once plugin_dir_path(__FILE__) . 'includes/booking-handler.php';
require_once plugin_dir_path(__FILE__) . 'includes/shortcode-render.php';

// Create tables on activation
register_activation_hook(__FILE__, 'mrbs_create_tables');
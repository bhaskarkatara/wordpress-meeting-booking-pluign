<?php
echo "<p>✅ Form loaded</p>";
global $wpdb;
$room_table = $wpdb->prefix . 'meeting_rooms';
$rooms = $wpdb->get_results("SELECT * FROM $room_table");

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['mrbs_booking_submit'])) {
    $room_id = intval($_POST['room_id']);
    $date = sanitize_text_field($_POST['booking_date']);
    $time = sanitize_text_field($_POST['booking_time']);
    $title = sanitize_text_field($_POST['meeting_title']);
    $user_id = get_current_user_id();

    if (empty($title)) {
        echo "<div class='notice notice-error'><p><strong>Please enter a meeting title.</strong></p></div>";
    } else {
        $table = $wpdb->prefix . 'meeting_bookings';

        // Check for duplicate booking
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE room_id = %d AND booking_date = %s AND booking_time = %s",
            $room_id, $date, $time
        ));

        if ($existing == 0) {
            $wpdb->insert($table, [
                'room_id' => $room_id,
                'booking_date' => $date,
                'booking_time' => $time,
                'booked_by' => $user_id,
                'title' => $title
            ]);

            echo "<div class='notice notice-success'><p><strong>✅ Meeting booked successfully!</strong></p></div>";
        } else {
            echo "<div class='notice notice-error'><p><strong>⚠️ This slot is already booked.</strong></p></div>";
        }
    }
}
?>

<style>
    .mrbs-form-wrapper {
        max-width: 500px;
        padding: 20px;
        background: #fff;
        border: 1px solid #ccd0d4;
        border-radius: 8px;
        margin: 20px auto;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }

    .mrbs-form-wrapper label {
        display: block;
        margin-top: 15px;
        font-weight: 600;
    }

    .mrbs-form-wrapper select,
    .mrbs-form-wrapper input[type="date"] {
        width: 100%;
        padding: 8px;
        margin-top: 5px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    .mrbs-form-wrapper input[type="submit"] {
        margin-top: 20px;
        padding: 10px 20px;
        background-color: #0073aa;
        border: none;
        color: #fff;
        border-radius: 4px;
        cursor: pointer;
    }

    .mrbs-form-wrapper input[type="submit"]:hover {
        background-color: #005177;
    }
</style>

<div class="mrbs-form-wrapper">
    <h2>📅 Book a Meeting Room</h2>

    <form method="post">
        <label for="room_id">Select Room:</label>
        <select name="room_id" id="room_id" required>
            <option value="">-- Select a Room --</option>
            <?php foreach ($rooms as $room): ?>
                <option value="<?= esc_attr($room->id) ?>"><?= esc_html($room->name) ?></option>
            <?php endforeach; ?>
        </select>

        <label for="meeting_title">Meeting Title:</label>
        <input type="text" name="meeting_title" id="meeting_title" required placeholder="e.g. Team Sync or Daily Standup">


        <label for="booking_date">Select Date:</label>
        <input type="date" name="booking_date" id="booking_date" required min="<?= date('Y-m-d') ?>">

        <label for="booking_time">Select Time (1-hour slots):</label>
        <select name="booking_time" id="booking_time" required>
            <option value="">-- Select a Time Slot --</option>
            <?php for ($i = 9; $i <= 17; $i++): ?>
                <option value="<?= sprintf('%02d:00:00', $i) ?>"><?= sprintf('%02d:00 - %02d:00', $i, $i + 1) ?></option>
            <?php endfor; ?>
        </select>

        <input type="submit" name="mrbs_booking_submit" value="Book Now">
    </form>
</div>
<?php

// ob_start(); // Start output buffering
error_log("✅ view-bookings.php included");
// echo "<p>✅ UI loaded from view-bookings.php</p>";

global $wpdb;

$room_table = $wpdb->prefix . 'meeting_rooms';
$booking_table = $wpdb->prefix . 'meeting_bookings';
$rooms = $wpdb->get_results("SELECT * FROM $room_table");
?>

<style>
    .mrbs-booking-view {
        max-width: 600px;
        padding: 20px;
        background: #fff;
        border: 1px solid #ccc;
        border-radius: 8px;
        margin: 20px auto;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }
    .mrbs-booking-view label {
        display: block;
        margin-top: 15px;
        font-weight: bold;
    }
    .mrbs-booking-view select, .mrbs-booking-view input[type="date"] {
        width: 100%;
        padding: 8px;
        margin-top: 5px;
        border-radius: 4px;
        border: 1px solid #ccc;
    }
    .mrbs-booking-view input[type="submit"] {
        margin-top: 20px;
        background: #0073aa;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
    .mrbs-booking-view input[type="submit"]:hover {
        background: #005177;
    }
    .mrbs-booking-view ul {
        margin-top: 20px;
        padding-left: 20px;
    }
</style>

<div class="mrbs-booking-view">
    <h2>📖 View Bookings</h2>
    <form method="post">
        <label for="room_id">Select Room:</label>
        <select name="room_id" required>
            <option value="">-- Select Room --</option>
            <?php foreach ($rooms as $room): ?>
                <option value="<?php echo esc_attr($room->id); ?>" <?php if (isset($_POST['room_id']) && $_POST['room_id'] == $room->id) echo 'selected'; ?>>
                    <?php echo esc_html($room->name); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="booking_date">Select Date:</label>
        <input type="date" name="booking_date" required value="<?php echo esc_attr($_POST['booking_date'] ?? ''); ?>">

        <input type="submit" name="view_bookings" value="View Bookings">
    </form>

    <?php
    if (isset($_POST['view_bookings'])) {
        $room_id = intval($_POST['room_id']);
        $date = sanitize_text_field($_POST['booking_date']);

        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $booking_table WHERE room_id = %d AND booking_date = %s ORDER BY booking_time",
            $room_id, $date
        ));

        echo '<h3>📅 Bookings for ' . esc_html(date("d M Y", strtotime($date))) . '</h3>';

        if ($results && count($results) > 0) {
            echo '<ul>';
            foreach ($results as $booking) {
              echo '<li>🕒 ' . esc_html(date("H:i", strtotime($booking->booking_time))) .
                    ' — ' . esc_html($booking->title) .
                    ' (User ID: ' . esc_html($booking->booked_by ?? 'Guest') . ')</li>';

            }
            echo '</ul>';
        } else {
            echo '<p>No bookings found for this date.</p>';
        }
    }
    ?>
</div>

<?php
// return ob_get_clean(); // Return for shortcode output